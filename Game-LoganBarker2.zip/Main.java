import java.util.*;

class Main {
  public static void main(String[]args){

    System.out.print("\033\143");   //clears console

    Scanner input = new Scanner(System.in);

    System.out.println("Welcome to school");                        //gives setting
    System.out.println("You see lots of kids all over the campus");
    System.out.println("Press enter to enter the school");
    input.nextLine();

    System.out.println("\uD83D\uDEB6 \uD83D\uDEB6 \uD83D\uDEB6");   // asking origional question
    System.out.println("You have entered the school");
    System.out.println("Do go and get breakfast or wait in your class?");
    String direction = input.next();
    direction = direction.toLowerCase();

    System.out.print("\033\143");

    if(direction.equals("breakfast")){                               // breackfast direction
      System.out.println("For breakfast they are serving pancakes or a hotpocket");
      System.out.println("what would you like for breakfast?");
      String food = input.next();
      food = food.toLowerCase();
      if(food.equals("pancakes")){
        System.out.print("You hade delisious pancakes and orange joice for breakfast"); // choice panckakes
        }else if(food.equals("hotpocket")){
        System.out.print("you had a delisious hot pocket with apple slices and milk");  // choice hotpocket
        }
    }else if (direction.equals("class")){                              // class direction
    System.out.println("You have entered your first class");
    System.out.println("do you want to talk to your teacher or sit quietly and wait for the bell?");
    String classs = input.next();
    classs = classs.toLowerCase();
    if (classs.equals("talk")){
      System.out.println("You talk to your teacher until the bell rings");                      // choice talk
      System.out.println("your teacher has begun to like you and increased your grade");
    }else if (classs.equals("wait")){
      System.out.println("you don't say anything until the bell rings and you begin working");  // choice wait
    }

    } else{
      System.out.print("This was not an option... reset my code please");         // not coded for
    }

  }
}